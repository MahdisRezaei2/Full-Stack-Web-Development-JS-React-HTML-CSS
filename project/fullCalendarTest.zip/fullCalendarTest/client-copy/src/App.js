import Modal from 'react-modal';
import Calendar from './Components/Calendar';


Modal.setAppElement('#root');

function App(props) {
  
  return (
   <Calendar />
   
  );
}

export default App;
